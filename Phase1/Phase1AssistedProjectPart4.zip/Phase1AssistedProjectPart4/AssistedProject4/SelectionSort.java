package project4;

public class SelectionSort {
	
	public static void sort(int[] arr) {
		
		for (int i = 0; i < arr.length; i++) {
			
			int Index = i;
			
			for (int j = i + 1; j < arr.length; j++) {
				
				if (arr[j] < arr[Index]) {
					
					Index = j;
					
					}
				}
			int temp = arr[i];
			arr[i] = arr[Index];
			arr[Index] = temp;
		}

	}

	public static void main(String[] args) {
		
		int[] arr = { 9, 2, 4, 6, 7, 3, 1, 8 };
		
		SelectionSort.sort(arr);
		
		System.out.println("After sorting:");
		
		for (int sort : arr) {
			
			System.out.print(sort + " ");
		}

	}

}
