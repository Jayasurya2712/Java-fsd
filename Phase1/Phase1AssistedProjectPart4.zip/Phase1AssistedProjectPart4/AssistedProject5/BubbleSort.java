package project;

public class BubbleSort {
	
	public static void sort(int[] arr) {
		for(int i=0;i<arr.length-1;i++) {
			for(int j=0;j<arr.length-1-i;j++) {
				if(arr[j]>arr[j+1]) {
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}			
	}
	public static void main(String[] args) {
		
  int[] arr= { 9, 2, 4, 6, 7, 3, 1, 8};
  
  BubbleSort.sort(arr); 
  System.out.println("After  sorting:");
  for(int sort:arr) {
  	System.out.print(sort+" ");
  	}
  
  }
	
}
