package Projects;

import java.util.Scanner;

public class LinearSearch {
	
	 public static int linearSearch(int[] arr, int target) {
	        for (int i = 0; i < arr.length; i++) {
	            if (arr[i] == target) {
	                return i; 
	            }
	        }
	        return -1; 
	    }

	    public static void main(String[] args) {
	        int[] array = {5, 2, 9, 1, 7, 4, 6, 3};
	        Scanner sc = new Scanner(System.in);

	        System.out.print("Enter the number to search: ");
	        int target = sc.nextInt();

	        int index = linearSearch(array, target);

	        if (index != -1) {
	            System.out.println("Element found at index " + index);
	        } else {
	            System.out.println("Element not found in the array");
	    }
	}


}
