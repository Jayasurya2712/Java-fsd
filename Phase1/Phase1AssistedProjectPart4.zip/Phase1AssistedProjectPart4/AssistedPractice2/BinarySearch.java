package access;

public class BinarySearch {
	public static  void main(String[] args){


        int[] arr = {1,2,4,8,15,18,64};
        int target = 64;
        int length = arr.length;
        binarySearch(arr,0,target,length);
    }

public static void binarySearch(int[] arr, int start, int target, int length){

        int mid = (start+length)/2;
        while(start<=length){

            if(arr[mid]<target){

                start = mid + 1;
            } else if(arr[mid]==target){
                System.out.println("Target is found at index :"+mid);
                break;
            }else {

                length=mid-1;
            }
            mid = (start+length)/2;
        }
            if(start>length){

                System.out.println("Target is not found");
            }

}

}
