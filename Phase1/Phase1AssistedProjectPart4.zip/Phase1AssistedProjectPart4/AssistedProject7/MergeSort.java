package project7;
import java.util.*;

public class MergeSort {
	public static int[] sort(int[] arr) {
		if (arr.length == 1)
			return arr;
		int mid = arr.length / 2;
		int[] left = sort(Arrays.copyOfRange(arr, 0, mid));
		int[] right = sort(Arrays.copyOfRange(arr, mid, arr.length));

		return merge(left, right);

	}

	public static int[] merge(int[] first, int[] second) {
		int[] join = new int[first.length + second.length];
		int i = 0, j = 0, k = 0;

		while (i < first.length && j < second.length) {
			if (first[i] < second[j])
				join[k++] = first[i++];
			else
				join[k++] = second[j++];
		}

		while (i < first.length)
			join[k++] = first[i++];
		while (j < second.length)
			join[k++] = second[j++];

		return join;

	}

	public static void main(String[] args) {
		
		int[] arr = { 9, 2, 4, 6, 7, 3, 1, 8 };

		int[] result = MergeSort.sort(arr);

		System.out.println("After  sorting:");
		for (int num : result) {
			System.out.print(num + " ");
		}
	}

}
