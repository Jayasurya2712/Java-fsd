package Project3;

public class ExponentialSearch {
	 public static int exponentialSearch(int[] arr, int target) {
	        int size = arr.length;

	        if (arr[0] == target) {
	            return 0;
	        }

	        int i = 1;
	        while (i < size && arr[i] <= target) {
	            i *= 2;
	        }

	        int left = i / 2;
	        int right = Math.min(i, size - 1);

	        return binarySearch(arr, target, left, right);
	    }

	    public static int binarySearch(int[] arr, int target, int left, int right) {
	        while (left <= right) {
	            int mid = left + (right - left) / 2;

	            if (arr[mid] == target) {
	                return mid; 
	            }

	            if (arr[mid] < target) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }

	        return -1; 
	    }

	    public static void main(String[] args) {
	        int[] array = {1, 2, 3, 4, 5, 6, 7, 9};
	       
	        int target = 9;

	        int index = exponentialSearch(array, target);

	        if (index != -1) {
	            System.out.println("Target found at index " + index);
	        } else {
	            System.out.println("Target not found in the array");
	    }
	}

}
