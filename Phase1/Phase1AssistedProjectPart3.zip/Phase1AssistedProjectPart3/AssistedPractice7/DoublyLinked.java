package project7;

public class DoublyLinked {
	private ListNode head;
    private ListNode tail;
    private int size;

    private static class ListNode {
        private int data;
        private ListNode prev;
        private ListNode next;

        public ListNode(int data) {
            this.data = data;
        }
    }

    public void push(int value) {
        ListNode newNode = new ListNode(value);

        if (tail == null) {
            head = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
        }

        tail = newNode;
        size++;
    }

    public void printForward() {
        ListNode current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void printBackward() {
        ListNode current = tail;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        DoublyLinked list = new DoublyLinked();

        list.push(1);
        list.push(2);
        list.push(3);
        list.push(4);
        list.push(5);

        System.out.print("Traversal in Forward Direction: ");
        list.printForward();

        System.out.print("Traversal in Backward Direction: ");
        list.printBackward();
}


}
