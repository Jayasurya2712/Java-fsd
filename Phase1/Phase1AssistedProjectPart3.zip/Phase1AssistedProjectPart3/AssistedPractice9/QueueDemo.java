package project9;
import java.util.*;
public class QueueDemo {
	public static void main(String[] args) {
		Queue<String> queue = new LinkedList<>();
		queue.add("10");
		queue.add("20");
		queue.add("15");
		queue.add("45");
		queue.add("25");
	System.out.println("Queue after adding elments : " + queue);
	queue.remove();
	System.out.println("Element removed from front of queue: " + queue);
	System.out.println("After removing Head of Queue : " + queue);
	
	queue.add("40");
	System.out.println("Size of Queue : " + queue);
	    	}
}
