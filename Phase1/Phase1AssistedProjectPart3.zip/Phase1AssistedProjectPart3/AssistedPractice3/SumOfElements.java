package Project3;
import java.util.Scanner;


public class SumOfElements {
	public static void main(String[] args) {
		
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter number of elements in the array: ");
        int n = input.nextInt();
        int[] arr = new int[n];
        
        System.out.println("Enter elements of the array:");
        for(int i=0; i<n; i++) {
            arr[i] = input.nextInt();
        }
        
        System.out.print("Enter value of Left (0 <= Left <= " + (n-1) + "): ");
        int Left = input.nextInt();
        
        System.out.print("Enter value of Right (Left <= Right <= " + (n-1) + "): ");
        int Right = input.nextInt();
        
        
        int sum = 0;
        for(int i=Left; i<=Right; i++) {
            sum += arr[i];
        }
        
        System.out.println("The sum of elements in the range is: " + sum);

}
}