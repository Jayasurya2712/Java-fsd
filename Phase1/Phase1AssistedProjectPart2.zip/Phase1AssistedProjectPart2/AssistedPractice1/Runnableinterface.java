package Projects;
class Printer1 implements Runnable {
    
    @Override
    public void run() {
        System.out.println("Program executed through runnable interface");
    }
}

public class Runnableinterface {

    public static void main(String[] args) {
        Printer1 p1 = new Printer1();
        Thread t = new Thread(p1);
        t.start();
    }
}
