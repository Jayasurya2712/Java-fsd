package com.camerarental.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import com.camerarental.bean.Camera;



public class CameraService {
	
	private static List<Camera> cameraList = new ArrayList<>();
	private static int camID=0;
	private double walletBalance;
	
	public CameraService() {
		cameraList.add(new Camera(++camID, "Canon", "D500", 600.0, false));
        cameraList.add(new Camera(++camID, "Sony", "HD720", 550.0, false));
        cameraList.add(new Camera(++camID, "Raptor", "Red", 1000.0, false));
        cameraList.add(new Camera(++camID, "Nikon", "EOD5", 800.0, true));
        cameraList.add(new Camera(++camID, "Canon", "EOS500d",700.0, false));
        cameraList.add(new Camera(++camID, "Leica", "S160", 750.0, true));
        cameraList.add(new Camera(++camID, "Fuji", "11Lite", 400.0, false));
		
		walletBalance = 1200.0;
	}
	public int getCurrentId() {
		return camID;
	}
	public double getCurrentWalletBalance() {
		return walletBalance;
	}
	public void addCamera(int id, String brand, String model, double perDayRent) {
		Camera camera = new Camera(++camID, brand, model, perDayRent, false);
		cameraList.add(camera);
		camID++;
	}
	public List<Camera> getCameraList() {
		return cameraList;
	}
	public void displayCameraList() {
		if (cameraList.isEmpty()) {
			System.out.println("NO DATA PRESENT AT THIS MOMENT!");
			return;
		} else {
			System.out.println("==================================================================");
			System.out.println("CAMERA ID BRAND MODEL PRICE(PER DAY) STATUS");
			System.out.println("==================================================================");
			for (Camera camera : cameraList) {
				String status = camera.isAvailable() ? "Rented" : "Available";
				System.out.printf(" %-7d %-10s %-10s %-13.2f %-12s \n",camera.getId(), camera.getBrand(), camera.getModel(), camera.getPerDayRent(), status);
			}
			System.out.println("==================================================================");
		}
	}
	public void removeCameraById() {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		try {
			int cameraId = scanner.nextInt();
			scanner.nextLine();
			Camera cameraToRemove = null;
			for (Camera camera : cameraList) {
				if (camera.getId() == cameraId) {
					cameraToRemove = camera;
					break;
				}
			}
			if (cameraToRemove != null) {
				cameraList.remove(cameraToRemove);
				System.out.println("CAMERA SUCCESSFULLY REMOVED FROM THE LIST.");
			} else {
				System.out.println("CAMERA WITH MENTIONED ID NOT FOUND IN THE LIST.");
			}
		} catch (InputMismatchException e) {
			System.out.println("Invalid input. Please enter a valid integer camera ID.");
			scanner.nextLine(); 
		}
	}
	public void displayAvailableCameras() {
		System.out.println("======================================================================");
		System.out.printf("%-10s %-15s %-15s %-15s %-15s%n", "CAMERA ID","BRAND", "MODEL", "PRICE(PER DAY)", "STATUS");
		System.out.println("======================================================================");
		boolean availableCamerasExist = false;
		for (Camera camera : cameraList) {
			if (!camera.isAvailable()) {
				availableCamerasExist = true;
				System.out.printf("%-10d %-15s %-15s %.2f %-20s%n", 
						camera.getId(), camera.getBrand(), camera.getModel(), camera.getPerDayRent(), " Available");
			}
		}
		if (!availableCamerasExist) {
			System.out.println("NO AVAILABLE CAMERA AT THIS MOMENT !");
		}
	}
	public void rentCamera(int cameraId, Camera camera) {
		Camera selectedCamera = null;
		for (Camera c : cameraList) {
			if (c.getId() == cameraId) {
				selectedCamera = c;
				break;
			}
		}
		if (selectedCamera == null) {
			System.out.println("CAMERA WITH ID " + cameraId + " NOT FOUND.");
			return;
		}
		if (selectedCamera.isAvailable()) {
			System.out.println("CAMERA WITH ID " + cameraId + " IS ALREADY RENTED.");
			return;
		}
		if (walletBalance < selectedCamera.getPerDayRent()) {
			System.out.println("ERROR : TRANSACTION FAILED DUE TO INSUFFICIENT WALLET BALANCE. PLEASE DEPOSIT THE AMOUNT TO YOUR WALLET.");
					return;
		}
		selectedCamera.setAvailable(true);
		walletBalance -= selectedCamera.getPerDayRent();
		System.out.printf("YOUR TRANSACTION FOR CAMERA - %s %s WITH RENT NR.%.2f HAS SUCCESSFULLY COMPLETED.\n",
				selectedCamera.getBrand(), selectedCamera.getModel(), 
				selectedCamera.getPerDayRent());
	}
	public void depositToWallet(double amount) {
		walletBalance += amount;
		System.out.println("YOUR WALLET BALANCE UPDATED SUCCESSFULLY. CURRENT WALLET BALANCE - INR." + walletBalance);
	}
	public void sortCameraList() {
		Collections.sort(cameraList, 
				Comparator.comparing(Camera::getBrand).thenComparing(Camera::getModel));
	}

}
