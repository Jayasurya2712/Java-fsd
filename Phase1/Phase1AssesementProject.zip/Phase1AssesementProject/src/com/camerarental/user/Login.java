package com.camerarental.user;

import java.util.ArrayList;
import java.util.List;


public class Login {
private List<User> userList;
	
	public Login() {
		userList = new ArrayList<>();
		userList.add(new User("admin", "admin")); // Login Credentials
	}
	
	public boolean authenticateUser(String username, String password) {
		for (User user : userList) {
			if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
				return true;
			}
		}
		return false;
	}

}
