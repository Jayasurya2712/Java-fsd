package com.camerarental.bean;

public class Camera {
	private int id;
	private String brand;
	private String model;
	private double perDayRent;
	private boolean available;
	
	public Camera(int id, String brand, String model, double perDayRent, boolean available) {
		this.id = id;
		this.brand = brand;
		this.model = model;
		this.perDayRent = perDayRent;
		this.available = available; 
	}
	public void Camera1(int i, String string, String string2, double d, boolean b) {
		
	}
	
	public int getId() {
		return id;
	}
	public String getBrand() {
		return brand;
	}
	public String getModel() {
		return model;
	}
	public double getPerDayRent() {
		return perDayRent;
	}
	public boolean isAvailable() {
		return available;
	}
	
	public void setAvailable(boolean available) {
		this.available = available;
	}

}
