package project6;
class MyException extends Exception{
	   String str1;
	   MyException(String str2) {
		str1=str2;
	   }
	   public String toString(){ 
		return ("MyException Occurred: "+str1) ;
	   }
	}

public class Handling {
	public static void main(String args[]){
		try{
			System.out.println("Trying to start block");
			
			throw new MyException("Getting Error");
		}
		catch(MyException exp){
			System.out.println("catch block Executed") ;
			System.out.println(exp) ;
		}
	   }


}
