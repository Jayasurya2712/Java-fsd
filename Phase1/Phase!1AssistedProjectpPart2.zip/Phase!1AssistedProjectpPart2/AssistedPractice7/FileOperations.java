package project7;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.util.Scanner;

public class FileOperations{
    public static void main(String[] args) {
        String fileName = "example.txt";

        
        try {
            File file = new File(fileName);
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("Error occurred while creating the file.");
            e.printStackTrace();
        }

       
        try {
            FileWriter writer = new FileWriter(fileName);
            writer.write("Hello Folks!\n");
            writer.write("This is a test file created from Eclipse.\n");
            writer.close();
            System.out.println("Successfully written to the file.");
        } catch (IOException e) {
            System.out.println("Error occurred while writing to the file.");
            e.printStackTrace();
        }

        try {
            File file = new File(fileName);
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                System.out.println(line);
            }
            scanner.close();
        } catch (IOException e) {
            System.out.println("error occurred while reading from the file.");
            e.printStackTrace();
        }

      
        try {
            FileWriter writer = new FileWriter(fileName, true);
            writer.write("This line is appended to the file.\n");
            writer.close();
            System.out.println("Successfully updated the file.");
        } catch (IOException e) {
            System.out.println("Error occurred while updating the file.");
            e.printStackTrace();
        }


        try {
            File file = new File(fileName);
            if (file.delete()) {
                System.out.println("File deleted: " + file.getName());
            } else {
                System.out.println("Unable to delete the file.");
            }
        } catch (Exception e) {
            System.out.println("Error occurred while deleting the file.");
            e.printStackTrace();
        }
    }
}
