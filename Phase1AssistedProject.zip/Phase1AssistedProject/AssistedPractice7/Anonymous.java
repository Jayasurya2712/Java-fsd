package project7;
class Ainner
{
	
	public void display()
	{ 
		System.out.println("Project7");
	}
	
}

public class Anonymous{

	public static void main(String[] args) {
		
		Ainner obj=new Ainner()
		{
			public void show()
			{
			
				System.out.println("In New Show");
			}
		};
		obj.display();
	}

}