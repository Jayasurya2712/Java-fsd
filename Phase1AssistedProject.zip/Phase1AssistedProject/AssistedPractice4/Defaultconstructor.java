package project4;

public class Defaultconstructor {
    int id;
    String name;
    
    
    public Defaultconstructor() {
        id = 0;
        name = null;
    }
    
    public void display() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
    }
    
    public static void main(String[] args) {
        
        Defaultconstructor obj = new Defaultconstructor();
        
        
        obj.display();
    }
}