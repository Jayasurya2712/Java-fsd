package project4;

class Employee {
    int id;
    String name;
    double salary;

   
    public Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    
    public void display() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Salary: " + salary);
    }
}

public class parameterizedconstructor {
    public static void main(String[] args) {
        
        Employee emp1 = new Employee(1, "Surya", 50000.0);
        Employee emp2 = new Employee(2, "Sami", 60000.0);

        // Calling the display method on both objects
        emp1.display();
        emp2.display();
    }
}
