package access;

class MyClass {
	  int x; 
	  
	  void printX() { 
	    System.out.println("x = " + x);
	  }
	}

	public class Defaultmodifier {
	  public static void main(String[] args) {
	    MyClass obj = new MyClass();
	    obj.x = 5; 
	    obj.printX(); 
	  }
	}