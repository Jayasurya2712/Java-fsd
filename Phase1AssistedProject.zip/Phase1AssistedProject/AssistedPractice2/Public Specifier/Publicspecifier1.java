package access2;
import access.*;

public class Publicspecifier1 {
	public static void main(String[] args) {
		
        Publicspecifier myObject = new Publicspecifier();
        
        myObject.myPublicVariable = 10;
        System.out.println("myPublicVariable value: " + myObject.myPublicVariable);
        
        
        myObject.myPublicMethod();

}
}