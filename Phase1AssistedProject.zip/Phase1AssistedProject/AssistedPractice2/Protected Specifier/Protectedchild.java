package access2;

import access.ProtectedAnimal;

public class Protectedchild extends ProtectedAnimal{
	
	public static void main(String[] args) {
		
		Protectedchild obj = new Protectedchild();   
		
	       obj.display();  
	}
}
