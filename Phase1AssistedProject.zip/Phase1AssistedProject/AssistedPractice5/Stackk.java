package project5;
import java.util.*;
public class Stackk {

	public static void main(String[] args) {
		
		Stack<String> s=new Stack<String>();
		s.push("TN");
		s.push("AP");
		s.push("KA");
		System.out.println(s);
		s.pop();
		System.out.println(s);
	}

}
