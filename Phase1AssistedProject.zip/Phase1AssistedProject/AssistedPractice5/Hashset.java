package project5;

import java.util.*;
public class Hashset {

	public static void main(String[] args) {
	
		HashSet<String> hs=new HashSet<String>();
		hs.add("surya");
		hs.add("sami");
		hs.add("kavi");
		System.out.print(hs);
		System.out.println(hs.contains("sami"));
	}

}