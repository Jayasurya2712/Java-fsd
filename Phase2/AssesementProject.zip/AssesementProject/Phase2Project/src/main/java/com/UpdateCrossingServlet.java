package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/updateCrossing")
public class UpdateCrossingServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String idParam = request.getParameter("crossingId");
			if (idParam != null && !idParam.isEmpty()) {
				int crossingId = Integer.parseInt(idParam);

				String name = request.getParameter("name");
				String address = request.getParameter("address");
				String landmark = request.getParameter("landmark");
				String trainSchedules = request.getParameter("trainSchedules");
				String personInCharge = request.getParameter("personInCharge");
				String status = request.getParameter("status");

				RailwayCrossing updatedCrossing = new RailwayCrossing();
				updatedCrossing.setId(crossingId);
				updatedCrossing.setName(name);
				updatedCrossing.setAddress(address);
				updatedCrossing.setLandmark(landmark);
				updatedCrossing.setTrainSchedule(trainSchedules);
				updatedCrossing.setPersonInCharge(personInCharge);
				updatedCrossing.setStatus(status);

				RailwayCrossingDAO crossingDAO = new RailwayCrossingDAO();
				crossingDAO.updateCrossing(updatedCrossing);

				response.sendRedirect("adminHome.jsp");
			} else {

				throw new ServletException("Crossing ID is missing.");
			}
		} catch (NumberFormatException e) {

			throw new ServletException("Invalid Crossing ID format.", e);
		} catch (Exception e) {

			throw new ServletException("An error occurred during the crossing update.", e);
		}
	}
}