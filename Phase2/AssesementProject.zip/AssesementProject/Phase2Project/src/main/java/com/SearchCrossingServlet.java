package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "searchCrossingServlet", urlPatterns = { "/searchCrossing" })
public class SearchCrossingServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int searchId = Integer.parseInt(request.getParameter("searchId"));

		RailwayCrossingDAO crossingDAO = new RailwayCrossingDAO();
		RailwayCrossing crossing = crossingDAO.getCrossingById(searchId);
		request.setAttribute("crossing", crossing);
		request.getRequestDispatcher("adminHome.jsp").forward(request, response);
	}
}