package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/deleteCrossing")
public class DeleteCrossingServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int crossingId = Integer.parseInt(request.getParameter("id"));

		RailwayCrossingDAO crossingDAO = new RailwayCrossingDAO();
		crossingDAO.deleteCrossing(crossingId);

		response.sendRedirect("adminHome.jsp");
	}
}