import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductsComponent } from './products/products.component';
import { ConvertToSpacePipe } from './convert-to-space.pipe';
import { ConvertToSpacesPipe } from './products/convert-to-spaces.pipe';

@NgModule({
  declarations: [
    AppComponent,
    ProductsComponent,
    ConvertToSpacePipe,
    ConvertToSpacesPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
