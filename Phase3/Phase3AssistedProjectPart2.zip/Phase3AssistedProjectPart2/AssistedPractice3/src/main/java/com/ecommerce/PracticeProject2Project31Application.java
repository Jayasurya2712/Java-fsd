package com.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeProject2Project31Application {

	public static void main(String[] args) {
		SpringApplication.run(PracticeProject2Project31Application.class, args);
	}

}
