package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeProject4Problem12Application {

	public static void main(String[] args) {
		SpringApplication.run(PracticeProject4Problem12Application.class, args);
	}

}
